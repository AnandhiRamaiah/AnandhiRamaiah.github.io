package PageTests;

import java.util.Iterator;

import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Academy.InitiateDriver;
import pageObjects.LandingPage;
import pageObjects.LoginPage;
import pageObjects.validateTitle;

public class HomePage extends InitiateDriver {
	
	private static Logger log =LogManager.getLogger(HomePage.class.getName());
	@BeforeTest
	public void initializebrowser() throws Exception{
		driver = initiatingDriver();
		log.info("Driver Initialized");
		
	}
	
	
	@Test(dataProvider ="getData")
	public void NavigatehomePage(String email, String Pwd) throws Exception{
	
		driver.get(prop.getProperty("TestURL"));
		log.info("navigated to base url");
		validateTitle titleInstance = new validateTitle(driver);
	    Assert.assertEquals(titleInstance.getTitle().getText(),"FEATURED COURSES");
		log.info("successfully validated msg");
		log.fatal("Assertion failed");
		LandingPage  landinginstance = new LandingPage(driver);
		landinginstance.LoginToLandingPage().click();
		LoginPage logininstance = new LoginPage(driver);
		logininstance.email().sendKeys(email);
		logininstance.password().sendKeys(Pwd);
		logininstance.loginbtn().click();			
		log.info("button click successfully");
	}
	
	@DataProvider
	public Object[][] getData(){
		
        Object obj [][] = new Object[3][2];
	    //3 sets
        //2 values each
		
		obj[0][0] = "TEst1";
		obj[0][1] = "VauleTest1";
		
		obj[1][0] = "TEst2";
		obj[1][1] = "VauleTest2";
		
		obj[2][0] = "TEst3";
		obj[2][1] = "VauleTest3";
		return obj;
		
	}
	
	
	@AfterTest
	public void teardown(){
		driver.close();
		driver=null;
	}

}
