package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Academy.InitiateDriver;


public class LoginPage {
	
	public WebDriver driver;
	
    By email =By.id("user_email");
    By password = By.id("user_password");
    By loginbtn  =By.xpath("//input[@name='commit']");
  	
			
	
	public LoginPage(WebDriver driver){
		this.driver = driver;
	}
	
	public WebElement email(){
		return driver.findElement(email);
	}

	public WebElement password(){
		return driver.findElement(password);
	}
	
	public WebElement loginbtn(){
		return driver.findElement(loginbtn);
	}
	
}

