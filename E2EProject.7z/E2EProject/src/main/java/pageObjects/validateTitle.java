package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Academy.InitiateDriver;

public class validateTitle {
	
public WebDriver driver;
	

   By getTitle = By.xpath("//h2[text()='Featured Courses']");
			
   
	public validateTitle(WebDriver driver){
		this.driver = driver;
	}
	
	
	public WebElement getTitle(){
		return driver.findElement(getTitle);
	}

}
