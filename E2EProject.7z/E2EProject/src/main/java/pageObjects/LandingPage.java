package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Academy.InitiateDriver;


public class LandingPage {
	
	public WebDriver driver;
	
	By login =By.xpath("//span[contains(text(),'Login')]");
	By initialpopup = By.className(".sumome-react-svg-image-container");
	
			
	
	public LandingPage(WebDriver driver){
		this.driver = driver;
	}
	
	public WebElement ClearInitialPopup(){
				return driver.findElement(initialpopup);
	}
		
	
	public WebElement LoginToLandingPage(){
		return driver.findElement(login);
	}

}
