package Academy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.core.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.google.common.io.Files;

public class InitiateDriver {

	public static WebDriver driver;
	public Properties prop = null;
	long PageLoadWait = 10;

	public WebDriver initiatingDriver() throws Exception {

		prop = new Properties();
		FileInputStream fis = new FileInputStream(".\\Installables\\data.properties");

		prop.load(fis);
		String browserName = prop.getProperty("browser");

		if (browserName.contains("chrome")) {
			// make sure to give the remote path, when Exe are present
			System.setProperty("webdriver.chrome.driver", ".\\Installables\\chromedriver.exe");
			ChromeOptions ch = new ChromeOptions();
			if (browserName.contains("headless")){
				ch.addArguments("headless");
			}
			
			driver = new ChromeDriver(ch);

		} else if (browserName.equalsIgnoreCase("IE")) {

		} else if (browserName.equalsIgnoreCase("FireFox")) {

		}

		// driver.manage().timeouts().implicitlyWait(PageLoadWait,
		// TimeUnit.SECONDS);
		driver.manage().window().maximize();
		return driver;
	}

	public void getScreenshots(String results) throws Exception {

		File src = (File) ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(src, new File("C:\\Users\\ramaia1\\Desktop\\BACKUPs\\Anandhi\\PERSONAL\\E2EProject\\Screenshots\\"
				+ results + "Screenshot.png"));

	}

}
