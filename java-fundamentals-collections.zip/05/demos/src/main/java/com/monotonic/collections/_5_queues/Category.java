package com.monotonic.collections._5_queues;

public enum Category
{
    PRINTER,
    COMPUTER,
    PHONE,
    TABLET
}
